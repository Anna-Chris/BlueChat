# BlueChat
A chat app via Bluetooth. Awesome,isn't it?
