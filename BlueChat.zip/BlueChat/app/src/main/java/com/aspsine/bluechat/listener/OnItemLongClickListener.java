package com.aspsine.bluechat.listener;

import android.view.View;

/**
 * Created by Aspsine on 2015/2/5.
 */
public interface OnItemLongClickListener {
    public void onItemLongClick(int position, View view);
}
