package com.aspsine.bluechat;

import android.app.Application;

/**
 * Created by littlexi on 2015/1/30.
 */
public class App extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
        CrashHandler.getInstance(getApplicationContext());
    }
}
