package com.aspsine.bluechat.listener;

import android.view.View;

/**
 * Created by Aspsine on 2015/2/5.
 */

public interface OnItemClickListener {
    public void onItemClick(int position, View view);
}